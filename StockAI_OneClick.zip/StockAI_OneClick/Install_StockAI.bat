@echo off
setlocal
cd /d "%~dp0"
set "APP=%LOCALAPPDATA%\StockAI"
set "PY=python"

echo.
echo ========================================
echo          StockAI One-Click Setup
echo ========================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Trying to install it automatically...
    where winget >nul 2>nul
    if errorlevel 1 (
        echo.
        echo Windows Package Manager (winget) was not found.
        echo Please install Python 3.11+ from python.org, then run this installer again.
        pause
        exit /b 1
    )
    winget install --id Python.Python.3.12 --exact --scope user --accept-source-agreements --accept-package-agreements
    if errorlevel 1 (
        echo Python installation failed.
        pause
        exit /b 1
    )
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
)

if not exist "%APP%" mkdir "%APP%"
copy /Y "StockAI.py" "%APP%\StockAI.py" >nul
copy /Y "requirements.txt" "%APP%\requirements.txt" >nul

echo Installing StockAI components (first time only)...
%PY% -m pip install --disable-pip-version-check --quiet -r "%APP%\requirements.txt"
if errorlevel 1 (
    echo.
    echo Dependency installation failed. Please run this installer again.
    pause
    exit /b 1
)

> "%APP%\Start StockAI.bat" echo @echo off
>> "%APP%\Start StockAI.bat" echo cd /d "%%~dp0"
>> "%APP%\Start StockAI.bat" echo start "" "%PY%" -m streamlit run StockAI.py

powershell -NoProfile -ExecutionPolicy Bypass -Command "$W=New-Object -ComObject WScript.Shell; $S=$W.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\StockAI.lnk'); $S.TargetPath='%APP%\Start StockAI.bat'; $S.WorkingDirectory='%APP%'; $S.IconLocation='shell32.dll,137'; $S.Save()"

start "" "%PY%" -m streamlit run "%APP%\StockAI.py"

echo.
echo StockAI is installed. A desktop shortcut was created.
endlocal
